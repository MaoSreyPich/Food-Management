 <!-- Use the new customer layout -->

<?php $__env->startSection('title','Customer Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center py-4">
  <h2 class="fw-bold mb-4">Welcome, <?php echo e(Auth::user()->name); ?> 👋</h2>
  <p>Browse our menu and place your order!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Food-Management\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>