<?php $__env->startSection('title','Welcome to SystemFood'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center mt-5">
  <h1 class="mb-3">🍔 Welcome to SystemFood 🍕</h1>
  <p class="lead">Browse our delicious menu and place your order!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Food-Management\resources\views/customer/home.blade.php ENDPATH**/ ?>