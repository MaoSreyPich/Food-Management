<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-4 text-center" style="font-family: sans-serif;">👤 Manage Users</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-hover align-middle text-center">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php echo e($user->role == 1 ? 'Admin' : 'User'); ?>

                </td>
                <td>
                    <span class="badge <?php echo e($user->status === 'active' ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e(ucfirst($user->status)); ?>

                    </span>
                </td>
                <td>
                    <form action="<?php echo e(route('admin.users.toggle', $user->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-md <?php echo e($user->status === 'active' ? 'btn-danger' : 'btn-success'); ?>">
                            <?php echo e($user->status === 'active' ? 'Block' : 'Unblock'); ?>

                        </button>
                    </form>
                
                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning btn-md">
                        Edit
                    </a>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<style>
  /* Import a modern, clean Google Font */
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
  
  body {
    font-family: 'Inter', sans-serif;
    font-size: 20px;
    color: #222;
    background-color: #f8fafc;
  }
  
  /* Table Styling */
  .table {
    border-radius: 12px;
    overflow: hidden;
    background: white;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  }
  
  .table th {
    background-color: #000;
    color: white;
    font-weight: 600;
    font-size:20px ;
    text-transform: uppercase;
  }
  
  .table td {
    font-size: 18px;
    vertical-align: middle;
  }
  
  h2.fw-bold {
    font-size: 28px;
    color: #111;
    letter-spacing: 0.5px;
  }
  .table td:last-child button {
    margin-top: 15px;
   }
  .table td a.btn-warning {
    margin-top: 15px;
   }
  .table td a.btn-warning:hover{
    background-color: orange;
   }


</style> 

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Food-Management\resources\views/admin/users/index.blade.php ENDPATH**/ ?>