@extends('layout.customer')

@section('title','Welcome to SystemFood')

@section('content')
<div class="text-center mt-5">
  <h1 class="mb-3">🍔 Welcome to SystemFood 🍕</h1>
  <p class="lead">Browse our delicious menu and place your order!</p>
</div>
@endsection
